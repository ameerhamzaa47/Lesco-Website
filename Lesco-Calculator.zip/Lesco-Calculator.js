document.getElementById('cal-block').style.display='none'

document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('units').addEventListener('keyup', calculateBill)

})

function calculateBill() {
    let unitsVal = document.getElementById('units')
    var coe=0

    if (unitsVal.value != null && unitsVal.value != undefined && unitsVal.value != '') {
        if (document.getElementById('cal-block').style.display != "block") {
    
            document.getElementById('cal-block').style.display = "block";
    
        }
        var val1 = document.getElementById('val1')
        var val2 = document.getElementById('val2')
        val1.style.display = "block";
        // val2.style.display = "block";
        
        // if (unitsVal.value <= 50) {

        //     val1.innerText = `${unitsVal.value} x 12.21= ${unitsVal.value * 12.21}`
        //     coe = unitsVal.value * 12.21
        //     val2.style.display = "none";

        // }

        // else 
        if (unitsVal.value <= 100) {
            val1.innerText = `${unitsVal.value} x 23.59 = ${unitsVal.value * 23.59}`
            coe = unitsVal.value * 23.59
            val2.style.display = "none";

        }

        else if (unitsVal.value <= 200) {
            val1.innerText = `${unitsVal.value} x 30.07 = ${(unitsVal.value)*30.07}`
            coe= (unitsVal.value)* 30.07
            // val2.innerText = `${unitsVal.value - 100} x 14.53 = ${(unitsVal.value - 100) * 14.53}`
            // coe = 100 * 12.21 + (unitsVal.value - 100) * 14.53

        }
        else if (unitsVal.value <= 300) {
            val1.innerText = `${unitsVal.value} x 34.26= ${(unitsVal.value)*34.26}`
            coe= (unitsVal.value)*34.26
            // val2.innerText = `${unitsVal.value - 200} x 31.51 = ${(unitsVal.value - 200) * 31.51}`
            // coe = 200 * 14.53 + (unitsVal.value - 200) * 31.51

        }
        else if (unitsVal.value <= 400) {
            val1.innerText = `${unitsVal.value} x 39.15= ${(unitsVal.value)* 39.15}`
            coe=(unitsVal.value)*39.15
            // val2.innerText = `${unitsVal.value - 300} x 38.41 = ${(unitsVal.value - 300) * 38.41}`
            // coe = 300 * 31.51 + (unitsVal.value - 300) * 38.41

        }
        else if (unitsVal.value <= 500) {
            val1.innerText = `${unitsVal.value} x 41.36= ${(unitsVal.value) * 41.36}`
            coe=(unitsVal.value)* 41.36
            // val2.innerText = `${unitsVal.value - 400} x 41.62 = ${(unitsVal.value - 400) * 41.62}`
            // coe = 400 * 38.41 + (unitsVal.value - 400) * 41.62

        }

        else if (unitsVal.value <= 600) {
            val1.innerText = `${unitsVal.value} x 42.78= ${(unitsVal.value) * 42.78}`
            coe= (unitsVal.value)* 42.78
            // val2.innerText = `${unitsVal.value - 500} x 43.04 = ${(unitsVal.value - 500) * 43.04}`
            // coe = 500 * 41.62 + (unitsVal.value - 500) * 43.04

        }
        else if (unitsVal.value <= 700) {
            val1.innerText = `${unitsVal.value} x 43.92= ${(unitsVal.value) * 43.92}`
            coe=(unitsVal.value)* 43.92
            // val2.innerText = `${unitsVal.value - 600} x 44.18 = ${(unitsVal.value - 600) * 44.18}`
            // coe = 600 * 43.04 + (unitsVal.value - 600) * 44.18

        }

        else {
            val1.innerText = `${unitsVal.value} x 48.84= ${(unitsVal.value)  * 48.84}`
            coe=(unitsVal.value)* 48.84
            // val2.innerText = `${unitsVal.value - 700} x 49.10 = ${(unitsVal.value - 700) * 49.10}`
            // coe = 700 * 44.18 + (unitsVal.value - 700) * 49.10
        }

        document.getElementById('coe').innerText = coe.toFixed(2);
        var eDuty = 1.5 / 100 * coe
        document.getElementById('eDuty').innerText = eDuty.toFixed(2)
        var njSurcharge = unitsVal.value / 100;
        document.getElementById('njSurcharge').innerText = njSurcharge.toFixed(2)
        var fcSurcharge = unitsVal.value * 0.43
        document.getElementById('fcSurcharge').innerText = fcSurcharge.toFixed(2);
        var gstariff = (coe + eDuty + fcSurcharge) * 17 / 100
        document.getElementById('gstariff').innerText = gstariff.toFixed(2)
        document.getElementById('bill-wDue').innerText = (coe + eDuty + njSurcharge + fcSurcharge + gstariff + 35 + 15).toFixed(2)
        var lpSurcharge = (coe + njSurcharge + fcSurcharge) * 0.1
        document.getElementById('lpSurcharge').innerText = lpSurcharge.toFixed(2)
        document.getElementById('bill-aDue').innerText = (coe + eDuty + njSurcharge + fcSurcharge + gstariff + 35 + 15 + lpSurcharge).toFixed(2)
    }
    
    else {
        document.getElementById('cal-block').style.display = "none";
    }
}